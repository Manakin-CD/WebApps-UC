/*
  # Remove discount and tax columns from maquila_closures table

  1. Changes
    - Remove `descuento` column
    - Remove `impuesto` column
    
  2. Notes
    - Safe removal of columns that were not requested
*/

ALTER TABLE maquila_closures
DROP COLUMN IF EXISTS descuento,
DROP COLUMN IF EXISTS impuesto;