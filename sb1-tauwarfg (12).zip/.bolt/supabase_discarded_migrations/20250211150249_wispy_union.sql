/*
  # Migrate comments to maquilas table

  1. Changes
    - Migrates existing comments from comments table to maquilas table
    - Ensures comments column is properly formatted as text
    - Drops the old comments table
  
  2. Security
    - Maintains existing RLS policies
*/

-- First ensure the comments column exists and is text
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'maquilas' AND column_name = 'comments'
  ) THEN
    ALTER TABLE maquilas ADD COLUMN comments text;
  END IF;
END $$;

-- Migrate existing comments to the maquilas table
DO $$ 
DECLARE
  maquila_record RECORD;
  comments_json text;
BEGIN
  FOR maquila_record IN SELECT id FROM maquilas LOOP
    -- Get all comments for this maquila and convert to JSON array
    SELECT json_agg(
      json_build_object(
        'content', content,
        'created_at', created_at
      )
    )::text
    INTO comments_json
    FROM comments
    WHERE maquila_id = maquila_record.id
    ORDER BY created_at DESC;

    -- Update the maquila with the comments
    IF comments_json IS NOT NULL THEN
      UPDATE maquilas
      SET comments = comments_json
      WHERE id = maquila_record.id;
    ELSE
      -- If no comments, set to empty array
      UPDATE maquilas
      SET comments = '[]'
      WHERE id = maquila_record.id;
    END IF;
  END LOOP;
END $$;

-- Set default value for comments column
ALTER TABLE maquilas 
ALTER COLUMN comments SET DEFAULT '[]';

-- Drop the old comments table if it exists
DROP TABLE IF EXISTS comments;