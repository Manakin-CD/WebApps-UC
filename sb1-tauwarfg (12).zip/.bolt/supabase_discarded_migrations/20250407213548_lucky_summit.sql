/*
  # Add discount and tax columns to maquila_closures table

  1. Changes
    - Add `descuento` column (numeric) to store discount percentage
    - Add `impuesto` column (numeric) to store tax percentage
    - Set default values to 0
    - Add check constraints to ensure values are between 0 and 100

  2. Notes
    - Both columns use numeric type for precise percentage calculations
    - Check constraints prevent invalid percentage values
*/

-- Add descuento column
ALTER TABLE maquila_closures
ADD COLUMN IF NOT EXISTS descuento numeric(5,2) NOT NULL DEFAULT 0
CHECK (descuento >= 0 AND descuento <= 100);

-- Add impuesto column
ALTER TABLE maquila_closures
ADD COLUMN IF NOT EXISTS impuesto numeric(5,2) NOT NULL DEFAULT 0
CHECK (impuesto >= 0 AND impuesto <= 100);