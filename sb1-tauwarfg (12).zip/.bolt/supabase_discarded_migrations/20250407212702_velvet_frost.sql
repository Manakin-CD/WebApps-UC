/*
  # Enhance maquila closures with additional fields

  1. Changes
    - Add `descuento` (discount) column to maquila_closures
    - Add `impuesto` (tax) column to maquila_closures
    - Update total calculation to include discount and tax
    
  2. Notes
    - Discount is a percentage (0-100)
    - Tax is a percentage (0-100)
    - Total is now: (cantidad * precio) * (1 - descuento/100) * (1 + impuesto/100)
*/

-- Add new columns with constraints
ALTER TABLE maquila_closures
ADD COLUMN descuento numeric(5,2) NOT NULL DEFAULT 0 CHECK (descuento >= 0 AND descuento <= 100),
ADD COLUMN impuesto numeric(5,2) NOT NULL DEFAULT 0 CHECK (impuesto >= 0 AND impuesto <= 100);

-- Drop the existing total column since we need to modify its calculation
ALTER TABLE maquila_closures DROP COLUMN IF EXISTS total;

-- Add the total column back with the new calculation
ALTER TABLE maquila_closures
ADD COLUMN total numeric(10,2) GENERATED ALWAYS AS (
  (cantidad * precio) * (1 - descuento/100) * (1 + impuesto/100)
) STORED;