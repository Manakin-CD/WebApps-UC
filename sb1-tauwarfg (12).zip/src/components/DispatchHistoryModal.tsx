import React, { useState, useEffect } from 'react';
import { X, FileDown, Search, Trash2, Ban } from 'lucide-react';
import type { Maquila } from '../types';
import { supabase } from '../lib/supabase';
import { generateDispatchSheet } from '../utils/dispatchSheetGenerator';

interface DispatchHistoryModalProps {
  maquila: Maquila;
  onClose: () => void;
}

interface DispatchRow {
  cantidad: string;
  descripcion: string;
  cliente: string;
  precio: number;
  talla: string;
}

interface DispatchSheet {
  id: string;
  consecutive_number: number;
  fecha_entrega: string;
  comentarios: string | null;
  created_at: string;
  cancelled: boolean;
  details: DispatchRow[];
}

export const DispatchHistoryModal: React.FC<DispatchHistoryModalProps> = ({
  maquila,
  onClose
}) => {
  const [dispatches, setDispatches] = useState<DispatchSheet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [regenerating, setRegenerating] = useState<number | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState<string | null>(null);

  useEffect(() => {
    fetchDispatchHistory();
  }, [maquila.id]);

  const fetchDispatchHistory = async () => {
    try {
      setLoading(true);
      setError(null);

      // First get all dispatch sheets
      const { data: dispatchesData, error: dispatchesError } = await supabase
        .from('dispatch_sheets')
        .select('*')
        .eq('maquila_id', maquila.id)
        .order('consecutive_number', { ascending: false });

      if (dispatchesError) throw dispatchesError;

      // Then get all details for these dispatches
      const dispatchesWithDetails = await Promise.all((dispatchesData || []).map(async (dispatch) => {
        const { data: detailsData, error: detailsError } = await supabase
          .from('dispatch_details')
          .select('cantidad, descripcion, cliente, precio, talla')
          .eq('dispatch_id', dispatch.id)
          .order('created_at', { ascending: true });

        if (detailsError) throw detailsError;

        return {
          ...dispatch,
          details: detailsData || []
        };
      }));

      setDispatches(dispatchesWithDetails);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al cargar el historial';
      setError(errorMessage);
      console.error('Error fetching dispatch history:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerateDispatch = async (dispatch: DispatchSheet) => {
    try {
      setRegenerating(dispatch.consecutive_number);
      await generateDispatchSheet({
        maquilaId: maquila.id,
        maquilaName: maquila.name,
        consecutiveNumber: dispatch.consecutive_number,
        fechaEntrega: dispatch.fecha_entrega,
        comentarios: dispatch.comentarios || '',
        rows: dispatch.details
      });
    } catch (error) {
      console.error('Error regenerating dispatch sheet:', error);
      alert('Error al regenerar la hoja de despacho');
    } finally {
      setRegenerating(null);
    }
  };

  const handleDeleteDispatch = async (dispatch: DispatchSheet) => {
    if (!window.confirm(`¿Está seguro que desea eliminar el despacho #${dispatch.consecutive_number.toString().padStart(3, '0')}? Esta acción no se puede deshacer.`)) {
      return;
    }

    try {
      setDeleting(dispatch.id);

      const { error: deleteError } = await supabase
        .from('dispatch_sheets')
        .delete()
        .eq('id', dispatch.id);

      if (deleteError) throw deleteError;

      // Update the local state to remove the deleted dispatch
      setDispatches(prev => prev.filter(d => d.id !== dispatch.id));
    } catch (error) {
      console.error('Error deleting dispatch:', error);
      alert('Error al eliminar el despacho');
    } finally {
      setDeleting(null);
    }
  };

  const handleCancelDispatch = async (dispatch: DispatchSheet) => {
    if (!window.confirm(`¿Está seguro que desea anular el despacho #${dispatch.consecutive_number.toString().padStart(3, '0')}? Esta acción no se puede deshacer.`)) {
      return;
    }

    try {
      setCancelling(dispatch.id);

      // First verify the dispatch exists and is not already cancelled
      const { data: existingDispatch, error: checkError } = await supabase
        .from('dispatch_sheets')
        .select('*')
        .eq('id', dispatch.id)
        .single();

      if (checkError) {
        if (checkError.message.includes('Results contain 0 rows')) {
          throw new Error('Despacho no encontrado');
        }
        throw checkError;
      }

      if (!existingDispatch) {
        throw new Error('Despacho no encontrado');
      }

      if (existingDispatch.cancelled) {
        throw new Error('El despacho ya está anulado');
      }

      // Delete corresponding closure entries
      const { error: deleteClosuresError } = await supabase
        .from('maquila_closures')
        .delete()
        .eq('maquila_id', maquila.id)
        .eq('dispatch_number', dispatch.consecutive_number);

      if (deleteClosuresError) throw deleteClosuresError;

      // Update the dispatch to cancelled state
      const { error: updateError } = await supabase
        .from('dispatch_sheets')
        .update({ cancelled: true })
        .eq('id', dispatch.id);

      if (updateError) throw updateError;

      // Update the local state with the updated dispatch
      setDispatches(prev => prev.map(d => {
        if (d.id === dispatch.id) {
          return {
            ...d,
            cancelled: true
          };
        }
        return d;
      }));

    } catch (error) {
      console.error('Error cancelling dispatch:', error);
      alert(error instanceof Error ? error.message : 'Error al anular el despacho');
    } finally {
      setCancelling(null);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('es-ES', {
      style: 'currency',
      currency: 'CRC'
    });
  };

  const formatConsecutiveNumber = (number: number): string => {
    return number.toString().padStart(3, '0');
  };

  const filteredDispatches = dispatches.filter(dispatch => {
    const searchLower = searchTerm.toLowerCase().trim();
    
    // If the search term is empty, show all dispatches
    if (!searchLower) return true;
    
    // Search by consecutive number (with or without leading zeros)
    const consecutiveMatch = formatConsecutiveNumber(dispatch.consecutive_number).includes(searchLower) ||
                           dispatch.consecutive_number.toString().includes(searchLower);
    
    // Search by date
    const dateMatch = formatDate(dispatch.fecha_entrega).toLowerCase().includes(searchLower);
    
    return consecutiveMatch || dateMatch;
  });

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
        >
          <X className="w-6 h-6" />
        </button>
        
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
          Historial de Hojas de Despacho - {maquila.name}
        </h2>

        <div className="mb-6">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar por número de boleta (ej: 001) o fecha..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Cargando historial...</p>
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-red-500 dark:text-red-400">{error}</p>
            <button
              onClick={fetchDispatchHistory}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Reintentar
            </button>
          </div>
        ) : filteredDispatches.length === 0 ? (
          <div className="text-center py-8 text-gray-600 dark:text-gray-400">
            No se encontraron hojas de despacho
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredDispatches.map((dispatch) => {
              const total = dispatch.details.reduce((sum, detail) => {
                const cantidad = parseInt(detail.cantidad) || 0;
                return sum + (cantidad * detail.precio);
              }, 0);

              return (
                <div
                  key={dispatch.id}
                  className={`bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow ${
                    dispatch.cancelled ? 'opacity-75' : ''
                  }`}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className={`text-lg font-semibold text-gray-900 dark:text-white ${
                          dispatch.cancelled ? 'line-through' : ''
                        }`}>
                          Despacho #{formatConsecutiveNumber(dispatch.consecutive_number)}
                        </h3>
                        {dispatch.cancelled && (
                          <span className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded dark:bg-red-900 dark:text-red-300">
                            Anulado
                          </span>
                        )}
                      </div>
                      <p className="text-gray-600 dark:text-gray-300">
                        Fecha de entrega: {formatDate(dispatch.fecha_entrega)}
                      </p>
                      <p className="text-gray-600 dark:text-gray-300">
                        Total: {formatCurrency(total)}
                      </p>
                      {dispatch.comentarios && (
                        <p className="text-gray-500 dark:text-gray-400 mt-1">
                          {dispatch.comentarios}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleRegenerateDispatch(dispatch)}
                        disabled={regenerating === dispatch.consecutive_number || dispatch.cancelled}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <FileDown size={18} />
                        {regenerating === dispatch.consecutive_number ? 'Generando...' : 'Regenerar PDF'}
                      </button>
                      {!dispatch.cancelled && (
                        <button
                          onClick={() => handleCancelDispatch(dispatch)}
                          disabled={cancelling === dispatch.id}
                          className="flex items-center gap-2 px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 disabled:opacity-50"
                        >
                          <Ban size={18} />
                          {cancelling === dispatch.id ? 'Anulando...' : 'Anular'}
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteDispatch(dispatch)}
                        disabled={deleting === dispatch.id}
                        className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
                      >
                        <Trash2 size={18} />
                        {deleting === dispatch.id ? 'Eliminando...' : 'Eliminar'}
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-gray-100 dark:bg-gray-600">
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Cantidad</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Descripción</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Talla</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Cliente</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Precio</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dispatch.details.map((detail, index) => {
                          const cantidad = parseInt(detail.cantidad) || 0;
                          const rowTotal = cantidad * detail.precio;
                          return (
                            <tr key={index} className={`border-t border-gray-200 dark:border-gray-600 ${
                              dispatch.cancelled ? 'line-through' : ''
                            }`}>
                              <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{detail.cantidad}</td>
                              <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{detail.descripcion}</td>
                              <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{detail.talla}</td>
                              <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{detail.cliente}</td>
                              <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{formatCurrency(detail.precio)}</td>
                              <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{formatCurrency(rowTotal)}</td>
                            </tr>
                          );
                        })}
                        <tr className="border-t-2 border-gray-300 dark:border-gray-500 font-bold">
                          <td colSpan={5} className="px-4 py-2 text-right text-gray-800 dark:text-gray-300">Total:</td>
                          <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{formatCurrency(total)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}