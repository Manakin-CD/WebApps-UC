import React, { useState, useEffect } from 'react';
import { X, FileDown, Search, Trash2 } from 'lucide-react';
import type { Maquila } from '../types';
import { supabase } from '../lib/supabase';
import { generateMaquilaClosurePDF } from '../utils/pdfGenerator';

interface ClosureHistoryModalProps {
  maquila: Maquila;
  onClose: () => void;
}

interface ClosureHistoryRow {
  id: string;
  tipo: string;
  cantidad: number;
  precio: number;
  total: number;
  fecha_cierre: string;
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const ClosureHistoryModal: React.FC<ClosureHistoryModalProps> = ({
  maquila,
  onClose
}) => {
  const [closures, setClosures] = useState<ClosureHistoryRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [regenerating, setRegenerating] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    fetchClosureHistory();
  }, [maquila.id]);

  const fetchClosureHistory = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('maquila_closure_history')
        .select('*')
        .eq('maquila_id', maquila.id)
        .order('fecha_cierre', { ascending: false });

      if (fetchError) throw fetchError;
      setClosures(data || []);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al cargar el historial';
      setError(errorMessage);
      console.error('Error fetching closure history:', err);
    } finally {
      setLoading(false);
    }
  };

  const verifyDeletion = async (date: string, maxRetries = 3): Promise<boolean> => {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      const { data, error } = await supabase
        .from('maquila_closure_history')
        .select('id')
        .eq('maquila_id', maquila.id)
        .eq('fecha_cierre', date);

      if (error) {
        console.error(`Verification attempt ${attempt} failed:`, error);
        if (attempt < maxRetries) {
          await sleep(500); // Wait 500ms before retrying
          continue;
        }
        throw error;
      }

      if (!data || data.length === 0) {
        return true; // Deletion verified successfully
      }

      if (attempt < maxRetries) {
        await sleep(500); // Wait 500ms before retrying
        continue;
      }
    }
    return false; // Deletion verification failed after all retries
  };

  const handleRegeneratePDF = async (closureDate: string) => {
    try {
      setRegenerating(closureDate);
      
      const { data: closuresForDate, error: fetchError } = await supabase
        .from('maquila_closure_history')
        .select('*')
        .eq('maquila_id', maquila.id)
        .eq('fecha_cierre', closureDate);

      if (fetchError) throw fetchError;
      
      if (closuresForDate && closuresForDate.length > 0) {
        await generateMaquilaClosurePDF(maquila, closuresForDate, maquila.advanceAmount);
      }
    } catch (error) {
      console.error('Error regenerating closure PDF:', error);
      alert('Error al regenerar el PDF del cierre');
    } finally {
      setRegenerating(null);
    }
  };

  const handleDeleteClosure = async (date: string) => {
    if (!window.confirm(`¿Está seguro que desea eliminar todos los cierres del ${formatDate(date)}? Esta acción no se puede deshacer.`)) {
      return;
    }

    try {
      setDeleting(date);

      // First verify the records exist and get their IDs
      const { data: existingClosures, error: checkError } = await supabase
        .from('maquila_closure_history')
        .select('id')
        .eq('maquila_id', maquila.id)
        .eq('fecha_cierre', date);

      if (checkError) throw checkError;

      if (!existingClosures || existingClosures.length === 0) {
        throw new Error('No se encontraron registros para eliminar');
      }

      // Delete the records
      const { error: deleteError } = await supabase
        .from('maquila_closure_history')
        .delete()
        .eq('maquila_id', maquila.id)
        .eq('fecha_cierre', date);

      if (deleteError) throw deleteError;

      // Verify deletion with retries
      const deletionVerified = await verifyDeletion(date);
      
      if (!deletionVerified) {
        throw new Error(`No se pudieron eliminar los cierres del ${formatDate(date)}. Por favor, intente nuevamente más tarde.`);
      }

      // Update local state only after successful deletion
      setClosures(prev => prev.filter(closure => closure.fecha_cierre !== date));
    } catch (error) {
      console.error('Error deleting closure history:', error);
      alert(error instanceof Error ? error.message : 'Error al eliminar el historial de cierre');
    } finally {
      setDeleting(null);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('es-ES', {
      style: 'currency',
      currency: 'CRC'
    });
  };

  const filteredClosures = closures.filter(closure => 
    closure.tipo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    formatDate(closure.fecha_cierre).toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group closures by fecha_cierre
  const groupedClosures = filteredClosures.reduce((acc, closure) => {
    const date = closure.fecha_cierre;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(closure);
    return acc;
  }, {} as Record<string, ClosureHistoryRow[]>);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
        >
          <X className="w-6 h-6" />
        </button>
        
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
          Historial de Cierres - {maquila.name}
        </h2>

        <div className="mb-6">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar por descripción o fecha..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Cargando historial...</p>
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-red-500 dark:text-red-400">{error}</p>
            <button
              onClick={fetchClosureHistory}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Reintentar
            </button>
          </div>
        ) : Object.keys(groupedClosures).length === 0 ? (
          <div className="text-center py-8 text-gray-600 dark:text-gray-400">
            No se encontraron cierres en el historial
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedClosures).map(([date, closures]) => {
              const totalForDate = closures.reduce((sum, closure) => sum + closure.total, 0);
              
              return (
                <div
                  key={date}
                  className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        Cierre del {formatDate(date)}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300">
                        Total del cierre: {formatCurrency(totalForDate)}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleRegeneratePDF(date)}
                        disabled={regenerating === date}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
                      >
                        <FileDown size={18} />
                        {regenerating === date ? 'Generando...' : 'Regenerar PDF'}
                      </button>
                      <button
                        onClick={() => handleDeleteClosure(date)}
                        disabled={deleting === date}
                        className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
                      >
                        <Trash2 size={18} />
                        {deleting === date ? 'Eliminando...' : 'Eliminar'}
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-gray-100 dark:bg-gray-600">
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Descripción</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Cantidad</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Precio</th>
                          <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {closures.map((closure) => (
                          <tr key={closure.id} className="border-t border-gray-200 dark:border-gray-600">
                            <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{closure.tipo}</td>
                            <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{closure.cantidad}</td>
                            <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{formatCurrency(closure.precio)}</td>
                            <td className="px-4 py-2 text-gray-800 dark:text-gray-300">{formatCurrency(closure.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};