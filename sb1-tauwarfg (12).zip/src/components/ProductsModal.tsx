import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Search, Pencil, Save } from 'lucide-react';
import type { Maquila } from '../types';
import { supabase } from '../lib/supabase';

interface ProductsModalProps {
  maquila: Maquila;
  onClose: () => void;
}

interface Product {
  id: string;
  descripcion: string;
  precio: number;
  cliente: string;
}

interface EditingProduct {
  id: string;
  descripcion: string;
  precio: string;
  cliente: string;
}

export const ProductsModal: React.FC<ProductsModalProps> = ({
  maquila,
  onClose
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [newProduct, setNewProduct] = useState({
    descripcion: '',
    precio: '',
    cliente: ''
  });
  const [editingProducts, setEditingProducts] = useState<{ [key: string]: EditingProduct }>({});

  useEffect(() => {
    fetchProducts();
  }, [maquila.id]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('maquila_products')
        .select('*')
        .eq('maquila_id', maquila.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setProducts(data || []);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al cargar los productos';
      setError(errorMessage);
      console.error('Error fetching products:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newProduct.descripcion.trim() || !newProduct.cliente.trim() || !newProduct.precio) {
      alert('Por favor complete todos los campos');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('maquila_products')
        .insert([{
          maquila_id: maquila.id,
          descripcion: newProduct.descripcion.trim(),
          precio: parseFloat(newProduct.precio),
          cliente: newProduct.cliente.trim()
        }])
        .select();

      if (error) throw error;
      
      if (data) {
        setProducts([...data, ...products]);
        setNewProduct({
          descripcion: '',
          precio: '',
          cliente: ''
        });
      }
    } catch (error) {
      console.error('Error adding product:', error);
      alert('Error al agregar el producto');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!window.confirm('¿Está seguro que desea eliminar este producto?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('maquila_products')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setProducts(products.filter(product => product.id !== id));
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Error al eliminar el producto');
    }
  };

  const handleStartEditing = (product: Product) => {
    setEditingProducts(prev => ({
      ...prev,
      [product.id]: {
        id: product.id,
        descripcion: product.descripcion,
        precio: product.precio.toString(),
        cliente: product.cliente
      }
    }));
  };

  const handleCancelEditing = (productId: string) => {
    setEditingProducts(prev => {
      const newState = { ...prev };
      delete newState[productId];
      return newState;
    });
  };

  const handleSaveEdit = async (productId: string) => {
    const editingProduct = editingProducts[productId];
    if (!editingProduct) return;

    if (!editingProduct.descripcion.trim() || !editingProduct.cliente.trim() || !editingProduct.precio) {
      alert('Por favor complete todos los campos');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('maquila_products')
        .update({
          descripcion: editingProduct.descripcion.trim(),
          precio: parseFloat(editingProduct.precio),
          cliente: editingProduct.cliente.trim()
        })
        .eq('id', productId)
        .select();

      if (error) throw error;
      
      if (data) {
        setProducts(products.map(product => 
          product.id === productId ? data[0] : product
        ));
        handleCancelEditing(productId);
      }
    } catch (error) {
      console.error('Error updating product:', error);
      alert('Error al actualizar el producto');
    }
  };

  const handleEditChange = (
    productId: string,
    field: keyof EditingProduct,
    value: string
  ) => {
    setEditingProducts(prev => ({
      ...prev,
      [productId]: {
        ...prev[productId],
        [field]: value
      }
    }));
  };

  const filteredProducts = products.filter(product => 
    product.descripcion.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.cliente.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
        >
          <X className="w-6 h-6" />
        </button>
        
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
          Productos - {maquila.name}
        </h2>

        <form onSubmit={handleAddProduct} className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Descripción
            </label>
            <input
              type="text"
              value={newProduct.descripcion}
              onChange={(e) => setNewProduct({ ...newProduct, descripcion: e.target.value })}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder="Ingrese descripción"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Precio
            </label>
            <input
              type="number"
              step="0.01"
              value={newProduct.precio}
              onChange={(e) => setNewProduct({ ...newProduct, precio: e.target.value })}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder="0.00"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Cliente
            </label>
            <input
              type="text"
              value={newProduct.cliente}
              onChange={(e) => setNewProduct({ ...newProduct, cliente: e.target.value })}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder="Ingrese cliente"
            />
          </div>
          <div className="md:col-span-3">
            <button
              type="submit"
              className="w-full bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 flex items-center justify-center gap-2"
            >
              <Plus size={18} />
              Agregar Producto
            </button>
          </div>
        </form>

        <div className="mb-6">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar por descripción o cliente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Cargando productos...</p>
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-red-500 dark:text-red-400">{error}</p>
            <button
              onClick={fetchProducts}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Reintentar
            </button>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-8 text-gray-600 dark:text-gray-400">
            No se encontraron productos
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-100 dark:bg-gray-700">
                  <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Descripción</th>
                  <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Precio</th>
                  <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Cliente</th>
                  <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product) => {
                  const isEditing = editingProducts[product.id];
                  return (
                    <tr key={product.id} className="border-t border-gray-200 dark:border-gray-600">
                      <td className="px-4 py-2 text-gray-800 dark:text-gray-300">
                        {isEditing ? (
                          <input
                            type="text"
                            value={isEditing.descripcion}
                            onChange={(e) => handleEditChange(product.id, 'descripcion', e.target.value)}
                            className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          />
                        ) : (
                          product.descripcion
                        )}
                      </td>
                      <td className="px-4 py-2 text-gray-800 dark:text-gray-300">
                        {isEditing ? (
                          <input
                            type="number"
                            step="0.01"
                            value={isEditing.precio}
                            onChange={(e) => handleEditChange(product.id, 'precio', e.target.value)}
                            className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          />
                        ) : (
                          product.precio.toLocaleString('es-ES', {
                            style: 'currency',
                            currency: 'CRC'
                          })
                        )}
                      </td>
                      <td className="px-4 py-2 text-gray-800 dark:text-gray-300">
                        {isEditing ? (
                          <input
                            type="text"
                            value={isEditing.cliente}
                            onChange={(e) => handleEditChange(product.id, 'cliente', e.target.value)}
                            className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          />
                        ) : (
                          product.cliente
                        )}
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex gap-2">
                          {isEditing ? (
                            <>
                              <button
                                onClick={() => handleSaveEdit(product.id)}
                                className="text-green-500 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                                title="Guardar cambios"
                              >
                                <Save size={18} />
                              </button>
                              <button
                                onClick={() => handleCancelEditing(product.id)}
                                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                                title="Cancelar edición"
                              >
                                <X size={18} />
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => handleStartEditing(product)}
                                className="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                                title="Editar producto"
                              >
                                <Pencil size={18} />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(product.id)}
                                className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                                title="Eliminar producto"
                              >
                                <Trash2 size={18} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};