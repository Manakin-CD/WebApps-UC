import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { supabase } from '../lib/supabase';

interface DispatchRow {
  cantidad: string;
  descripcion: string;
  cliente: string;
  precio: number;
  talla: string;
}

interface DispatchSheetData {
  maquilaId: string;
  maquilaName: string;
  fechaEntrega: string;
  comentarios: string;
  rows: DispatchRow[];
  consecutiveNumber?: number;
}

const formatDate = (dateString: string): string => {
  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  
  return date.toLocaleDateString('es-ES', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: 'UTC'
  });
};

const formatCurrency = (amount: number): string => {
  return amount.toLocaleString('es-ES', {
    style: 'currency',
    currency: 'CRC'
  });
};

const getNextDispatchNumber = async (): Promise<number> => {
  try {
    const { data, error } = await supabase
      .rpc('get_next_dispatch_number');

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error getting next dispatch number:', error);
    throw error;
  }
};

const saveDispatchSheet = async (
  maquilaId: string,
  consecutiveNumber: number,
  fechaEntrega: string,
  comentarios: string,
  rows: DispatchRow[]
): Promise<void> => {
  try {
    // First save the dispatch sheet
    const { data: dispatchSheet, error: dispatchError } = await supabase
      .from('dispatch_sheets')
      .insert({
        maquila_id: maquilaId,
        consecutive_number: consecutiveNumber,
        fecha_entrega: fechaEntrega,
        comentarios: comentarios
      })
      .select()
      .single();

    if (dispatchError) throw dispatchError;

    // Then save all the rows
    const rowsData = rows.map(row => ({
      dispatch_id: dispatchSheet.id,
      ...row
    }));

    const { error: detailsError } = await supabase
      .from('dispatch_details')
      .insert(rowsData);

    if (detailsError) throw detailsError;
  } catch (error) {
    console.error('Error saving dispatch sheet:', error);
    throw error;
  }
};

export const generateDispatchSheet = async (
  data: DispatchSheetData
): Promise<{ consecutiveNumber: number }> => {
  // Only get a new consecutive number if one wasn't provided (new dispatch sheet)
  const consecutiveNumber = data.consecutiveNumber || await getNextDispatchNumber();
  
  // Only save to database if this is a new dispatch sheet (no consecutive number provided)
  if (!data.consecutiveNumber) {
    await saveDispatchSheet(
      data.maquilaId,
      consecutiveNumber,
      data.fechaEntrega,
      data.comentarios,
      data.rows
    );
  }

  // Create a new PDF document
  const doc = new jsPDF();
  
  // Configure title
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Despacho de Maquila', 105, 15, { align: 'center' });
  
  // Consecutive number
  doc.setFontSize(14);
  doc.text(`N° ${consecutiveNumber.toString().padStart(3, '0')}`, 185, 15, { align: 'right' });
  
  // Maquila information
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`Nombre: ${data.maquilaName}`, 14, 35);
  
  // Dates
  const today = new Date().toLocaleDateString('es-ES', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  doc.text(`Fecha de Envío: ${today}`, 14, 45);
  doc.text(`Fecha de Entrega: ${formatDate(data.fechaEntrega)}`, 14, 55);
  
  // Common table configuration
  const tableConfig = {
    head: [['Cantidad', 'Descripción', 'Talla', 'Cliente', 'Precio', 'Total']],
    body: data.rows.map(row => {
      const cantidad = parseInt(row.cantidad) || 0;
      const rowTotal = cantidad * row.precio;
      return [
        row.cantidad,
        row.descripcion,
        row.talla,
        row.cliente,
        formatCurrency(row.precio),
        formatCurrency(rowTotal)
      ];
    }).concat([
      ['', '', '', '', 'Total:', formatCurrency(data.rows.reduce((sum, row) => {
        const cantidad = parseInt(row.cantidad) || 0;
        return sum + (cantidad * row.precio);
      }, 0))]
    ]),
    theme: 'grid',
    styles: {
      fontSize: 9,
      cellPadding: 2,
      lineColor: [0, 0, 0],
      lineWidth: 0.1,
    },
    columnStyles: {
      0: { cellWidth: 20 },  // Cantidad
      1: { cellWidth: 60 },  // Descripción
      2: { cellWidth: 20 },  // Talla
      3: { cellWidth: 30 },  // Cliente
      4: { cellWidth: 30 },  // Precio
      5: { cellWidth: 30 }   // Total
    },
    headStyles: {
      fillColor: [41, 128, 185],
      textColor: 255,
      fontStyle: 'bold',
      fontSize: 9,
      cellPadding: 2,
    },
    alternateRowStyles: {
      fillColor: [240, 240, 240],
    },
    footStyles: {
      fillColor: [220, 220, 220],
      fontStyle: 'bold',
    }
  };
  
  // Comments section with proper text wrapping
  if (data.comentarios.trim()) {
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    
    // Calculate maximum width for text wrapping (page width minus margins)
    const maxWidth = doc.internal.pageSize.width - 28; // 14mm margin on each side
    
    // Split comments into lines that fit within maxWidth
    const splitComments = doc.splitTextToSize(data.comentarios, maxWidth);
    
    // Draw comments with proper wrapping
    doc.text('Comentarios:', 14, 70);
    doc.text(splitComments, 14, 78);
    
    // Calculate required height for comments
    const lineHeight = 5; // Reduced line height
    const commentsHeight = splitComments.length * lineHeight;
    
    // Start table right after comments with minimal spacing
    autoTable(doc, {
      ...tableConfig,
      startY: 78 + commentsHeight + 3
    });
  } else {
    // If no comments, start table immediately after dates
    autoTable(doc, {
      ...tableConfig,
      startY: 65
    });
  }
  
  // Space for signature
  const finalY = (doc as any).lastAutoTable.finalY + 20;
  
  doc.setFont('helvetica', 'normal');
  doc.text('Firma de Recibido:', 14, finalY);
  doc.line(50, finalY, 150, finalY);
  
  // Footer
  doc.setFontSize(8);
  doc.text(
    'Uniformes Centroamericanos',
    105,
    doc.internal.pageSize.height - 10,
    { align: 'center' }
  );
  
  // Save the PDF
  const fileName = `Despacho_${consecutiveNumber.toString().padStart(3, '0')}_${data.maquilaName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(fileName);

  return { consecutiveNumber };
};