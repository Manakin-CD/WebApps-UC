/*
  # Add dispatch cancellation support

  1. Changes
    - Add cancelled column to dispatch_sheets table
    - Set default value to false
    - Add NOT NULL constraint
*/

ALTER TABLE dispatch_sheets
ADD COLUMN cancelled boolean NOT NULL DEFAULT false;