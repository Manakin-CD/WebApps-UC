/*
  # Add UPDATE policy for dispatch_sheets table

  1. Changes
    - Add policy to allow authenticated users to update dispatch sheets
    - Ensure policy allows cancellation of dispatch sheets
    
  2. Security
    - Only authenticated users can update dispatch sheets
    - Maintains existing RLS security model
*/

-- First check if policy already exists and drop it if it does
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'dispatch_sheets' 
    AND policyname = 'Authenticated update access'
  ) THEN
    DROP POLICY "Authenticated update access" ON dispatch_sheets;
  END IF;
END $$;

-- Create the UPDATE policy
CREATE POLICY "Authenticated update access"
  ON dispatch_sheets
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);