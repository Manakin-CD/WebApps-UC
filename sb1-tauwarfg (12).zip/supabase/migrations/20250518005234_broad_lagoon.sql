/*
  # Add size column to maquila closures

  1. Changes
    - Add talla column to maquila_closures table
    - Set default value to empty string
    - Add NOT NULL constraint
*/

ALTER TABLE maquila_closures
ADD COLUMN talla text NOT NULL DEFAULT '';