/*
  # Add talla column to dispatch details

  1. Changes
    - Add `talla` column to `dispatch_details` table
    - Set default value to empty string
    - Add NOT NULL constraint
*/

ALTER TABLE dispatch_details
ADD COLUMN talla text NOT NULL DEFAULT '';