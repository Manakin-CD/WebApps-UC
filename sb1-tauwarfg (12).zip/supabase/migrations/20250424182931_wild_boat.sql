/*
  # Add maquila products table

  1. New Table
    - `maquila_products`
      - `id` (uuid, primary key)
      - `maquila_id` (uuid, foreign key)
      - `descripcion` (text)
      - `precio` (numeric)
      - `cliente` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
    - Add cascade delete when maquila is deleted
*/

-- Create maquila products table
CREATE TABLE IF NOT EXISTS maquila_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  maquila_id uuid NOT NULL REFERENCES maquilas(id) ON DELETE CASCADE,
  descripcion text NOT NULL,
  precio numeric(10,2) NOT NULL CHECK (precio >= 0),
  cliente text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE maquila_products ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated read access"
  ON maquila_products FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated insert access"
  ON maquila_products FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated update access"
  ON maquila_products FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated delete access"
  ON maquila_products FOR DELETE
  TO authenticated
  USING (true);

-- Create indices
CREATE INDEX idx_maquila_products_maquila_id ON maquila_products(maquila_id);

-- Create trigger for updated_at
CREATE TRIGGER update_maquila_products_updated_at
  BEFORE UPDATE ON maquila_products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();