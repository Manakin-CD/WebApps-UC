/*
  # Add cancelled column to dispatch_sheets table

  1. Changes
    - Add cancelled column to dispatch_sheets table
    - Set default value to false
    - Add NOT NULL constraint
    - Update existing rows to have cancelled = false
*/

-- Add cancelled column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'dispatch_sheets' 
    AND column_name = 'cancelled'
  ) THEN
    ALTER TABLE dispatch_sheets
    ADD COLUMN cancelled boolean NOT NULL DEFAULT false;
  END IF;
END $$;