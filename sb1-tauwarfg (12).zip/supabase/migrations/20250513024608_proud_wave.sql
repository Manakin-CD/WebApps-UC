/*
  # Add dispatch number to maquila closures

  1. Changes
    - Add dispatch_number column to maquila_closures table
    - Create index for better performance
    - Add foreign key constraint to dispatch_sheets
    
  2. Notes
    - Uses composite unique constraint on dispatch_sheets to enable foreign key reference
    - Ensures data integrity between closures and dispatch sheets
*/

-- First create a unique constraint on dispatch_sheets
ALTER TABLE dispatch_sheets
ADD CONSTRAINT dispatch_sheets_maquila_consecutive_unique 
UNIQUE (maquila_id, consecutive_number);

-- Add dispatch number column to maquila_closures
ALTER TABLE maquila_closures
ADD COLUMN dispatch_number integer;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_maquila_closures_dispatch_number 
ON maquila_closures(dispatch_number);

-- Add foreign key constraint
ALTER TABLE maquila_closures
ADD CONSTRAINT fk_maquila_closures_dispatch_sheets
FOREIGN KEY (maquila_id, dispatch_number) 
REFERENCES dispatch_sheets(maquila_id, consecutive_number)
ON DELETE SET NULL;