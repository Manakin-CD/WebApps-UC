/*
  # Add dispatch sheet consecutive numbering system

  1. New Tables
    - `dispatch_counter`
      - `id` (uuid, primary key)
      - `current_value` (integer)
      - `updated_at` (timestamp)

  2. New Table
    - `dispatch_sheets`
      - `id` (uuid, primary key)
      - `maquila_id` (uuid, foreign key)
      - `consecutive_number` (integer)
      - `fecha_entrega` (date)
      - `comentarios` (text)
      - `created_at` (timestamp)

  3. Functions
    - get_next_dispatch_number(): Function to get and increment the counter
*/

-- Create dispatch counter table
CREATE TABLE IF NOT EXISTS dispatch_counter (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  current_value integer NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

-- Insert initial counter value if table is empty
INSERT INTO dispatch_counter (current_value)
SELECT 0
WHERE NOT EXISTS (SELECT 1 FROM dispatch_counter);

-- Create dispatch sheets table
CREATE TABLE IF NOT EXISTS dispatch_sheets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  maquila_id uuid NOT NULL REFERENCES maquilas(id) ON DELETE CASCADE,
  consecutive_number integer NOT NULL,
  fecha_entrega date NOT NULL,
  comentarios text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create function to get next number
CREATE OR REPLACE FUNCTION get_next_dispatch_number()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  next_value integer;
BEGIN
  -- Lock the table to prevent concurrent access
  LOCK TABLE dispatch_counter IN SHARE ROW EXCLUSIVE MODE;
  
  -- Get and increment the counter
  UPDATE dispatch_counter
  SET current_value = current_value + 1,
      updated_at = now()
  RETURNING current_value INTO next_value;
  
  RETURN next_value;
END;
$$;

-- Enable RLS
ALTER TABLE dispatch_counter ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispatch_sheets ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated read access"
  ON dispatch_counter FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated update access"
  ON dispatch_counter FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated read access"
  ON dispatch_sheets FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated insert access"
  ON dispatch_sheets FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create indices
CREATE INDEX idx_dispatch_sheets_maquila_id ON dispatch_sheets(maquila_id);
CREATE INDEX idx_dispatch_sheets_consecutive ON dispatch_sheets(consecutive_number);