/*
  # Verify and update cascade delete behavior

  1. Changes
    - Verify all foreign key constraints have ON DELETE CASCADE
    - Add missing cascade deletes where needed
    - Ensure all related tables are properly linked

  2. Tables Affected
    - maquila_closures
    - dispatch_sheets
    - dispatch_details
*/

-- First verify the existing constraints
DO $$ 
BEGIN
  -- Verify maquila_closures constraint
  IF EXISTS (
    SELECT 1 
    FROM information_schema.referential_constraints 
    WHERE constraint_name = 'maquila_closures_maquila_id_fkey'
  ) THEN
    ALTER TABLE maquila_closures 
    DROP CONSTRAINT maquila_closures_maquila_id_fkey;
  END IF;

  -- Verify dispatch_sheets constraint
  IF EXISTS (
    SELECT 1 
    FROM information_schema.referential_constraints 
    WHERE constraint_name = 'dispatch_sheets_maquila_id_fkey'
  ) THEN
    ALTER TABLE dispatch_sheets 
    DROP CONSTRAINT dispatch_sheets_maquila_id_fkey;
  END IF;
END $$;

-- Re-add constraints with CASCADE
ALTER TABLE maquila_closures
ADD CONSTRAINT maquila_closures_maquila_id_fkey 
FOREIGN KEY (maquila_id) 
REFERENCES maquilas(id) 
ON DELETE CASCADE;

ALTER TABLE dispatch_sheets
ADD CONSTRAINT dispatch_sheets_maquila_id_fkey 
FOREIGN KEY (maquila_id) 
REFERENCES maquilas(id) 
ON DELETE CASCADE;

-- Note: dispatch_details already has ON DELETE CASCADE through its relationship with dispatch_sheets