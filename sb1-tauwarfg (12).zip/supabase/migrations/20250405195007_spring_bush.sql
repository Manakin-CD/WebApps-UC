/*
  # Add dispatch details storage

  1. New Table
    - `dispatch_details`
      - `id` (uuid, primary key)
      - `dispatch_id` (uuid, foreign key to dispatch_sheets)
      - `cantidad` (text)
      - `descripcion` (text)
      - `cliente` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create dispatch details table
CREATE TABLE IF NOT EXISTS dispatch_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispatch_id uuid NOT NULL REFERENCES dispatch_sheets(id) ON DELETE CASCADE,
  cantidad text NOT NULL,
  descripcion text NOT NULL,
  cliente text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE dispatch_details ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated read access"
  ON dispatch_details FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated insert access"
  ON dispatch_details FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create indices
CREATE INDEX idx_dispatch_details_dispatch_id ON dispatch_details(dispatch_id);

-- Create trigger for updated_at
CREATE TRIGGER update_dispatch_details_updated_at
  BEFORE UPDATE ON dispatch_details
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();