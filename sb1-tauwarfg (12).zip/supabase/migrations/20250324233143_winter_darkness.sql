/*
  # Fix dispatch counter function

  1. Changes
    - Update get_next_dispatch_number function to properly handle counter updates
    - Add WHERE clause to UPDATE statement
    - Ensure single row exists in dispatch_counter table
*/

-- First ensure we have exactly one counter row
TRUNCATE TABLE dispatch_counter;
INSERT INTO dispatch_counter (current_value) VALUES (0);

-- Update the function with proper WHERE clause
CREATE OR REPLACE FUNCTION get_next_dispatch_number()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  next_value integer;
BEGIN
  -- Lock the table to prevent concurrent access
  LOCK TABLE dispatch_counter IN SHARE ROW EXCLUSIVE MODE;
  
  -- Get current value
  SELECT current_value + 1
  INTO next_value
  FROM dispatch_counter
  LIMIT 1;
  
  -- Update the counter with WHERE clause
  UPDATE dispatch_counter
  SET current_value = next_value,
      updated_at = now()
  WHERE id = (SELECT id FROM dispatch_counter LIMIT 1);
  
  RETURN next_value;
END;
$$;