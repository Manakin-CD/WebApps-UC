/*
  # Add price column to dispatch details

  1. Changes
    - Add `precio` column to `dispatch_details` table
    - Set default value to 0
    - Add NOT NULL constraint
    - Add check constraint to ensure price is not negative

  2. Notes
    - Uses numeric type for precise currency calculations
    - Includes validation to prevent negative amounts
*/

ALTER TABLE dispatch_details
ADD COLUMN precio numeric(10,2) NOT NULL DEFAULT 0.00
CHECK (precio >= 0);