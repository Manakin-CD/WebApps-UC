/*
  # Fix dispatch cancellation column

  1. Changes
    - Ensure cancelled column exists with correct constraints
    - Add index for better query performance
    - Update any existing rows to have proper default value
*/

-- First verify if the column exists and has correct constraints
DO $$ 
BEGIN
  -- Drop existing column if it exists with wrong constraints
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'dispatch_sheets' 
    AND column_name = 'cancelled'
  ) THEN
    ALTER TABLE dispatch_sheets DROP COLUMN cancelled;
  END IF;
  
  -- Add column with correct constraints
  ALTER TABLE dispatch_sheets
  ADD COLUMN cancelled boolean NOT NULL DEFAULT false;
END $$;

-- Create index for better performance when querying cancelled status
CREATE INDEX IF NOT EXISTS idx_dispatch_sheets_cancelled 
ON dispatch_sheets(cancelled);

-- Update any existing rows to ensure they have the correct default value
UPDATE dispatch_sheets 
SET cancelled = false 
WHERE cancelled IS NULL;