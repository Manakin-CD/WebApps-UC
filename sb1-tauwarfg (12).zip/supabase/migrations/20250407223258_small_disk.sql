/*
  # Add closure history table and functionality

  1. New Table
    - `maquila_closure_history`
      - `id` (uuid, primary key)
      - `maquila_id` (uuid, foreign key)
      - `tipo` (text)
      - `cantidad` (integer)
      - `precio` (numeric)
      - `total` (numeric)
      - `fecha_cierre` (date)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create maquila closure history table
CREATE TABLE IF NOT EXISTS maquila_closure_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  maquila_id uuid NOT NULL REFERENCES maquilas(id) ON DELETE CASCADE,
  tipo text NOT NULL,
  cantidad integer NOT NULL CHECK (cantidad >= 0),
  precio numeric(10,2) NOT NULL CHECK (precio >= 0),
  total numeric(10,2) GENERATED ALWAYS AS (cantidad * precio) STORED,
  fecha_cierre date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE maquila_closure_history ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated read access"
  ON maquila_closure_history FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated insert access"
  ON maquila_closure_history FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create indices
CREATE INDEX idx_maquila_closure_history_maquila_id ON maquila_closure_history(maquila_id);
CREATE INDEX idx_maquila_closure_history_fecha_cierre ON maquila_closure_history(fecha_cierre);